import os, secrets, sqlite3
from datetime import datetime, timezone
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, flash, session, g, abort
from flask_wtf.csrf import CSRFProtect
from werkzeug.security import generate_password_hash, check_password_hash
import click

APP_DIR = os.path.abspath(os.path.dirname(__file__))
DB_PATH = os.environ.get("DATABASE_PATH", os.path.join(APP_DIR, "novapanel.db"))

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY")
if not app.config["SECRET_KEY"]:
    # Development fallback only. Set SECRET_KEY before deploying publicly.
    app.config["SECRET_KEY"] = secrets.token_hex(32)
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
app.config["SESSION_COOKIE_SECURE"] = os.environ.get("COOKIE_SECURE", "0") == "1"
app.config["PERMANENT_SESSION_LIFETIME"] = 60 * 60 * 8
CSRFProtect(app)

def connect_db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    return con

def init_db():
    with connect_db() as con:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL,
            referral_code TEXT NOT NULL UNIQUE,
            referred_by INTEGER REFERENCES users(id),
            role TEXT NOT NULL DEFAULT 'member',
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS wallet_requests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL REFERENCES users(id),
            amount REAL NOT NULL CHECK(amount > 0),
            request_type TEXT NOT NULL CHECK(request_type IN ('deposit_demo','withdrawal_demo')),
            status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved_demo','rejected')),
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS audit_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            actor_id INTEGER REFERENCES users(id),
            action TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        """)

def now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")

@app.before_request
def prepare():
    init_db()
    g.user = None
    uid = session.get("user_id")
    if uid:
        with connect_db() as con:
            g.user = con.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
        if not g.user:
            session.clear()

@app.context_processor
def inject_user():
    return {"current_user": getattr(g, "user", None)}

def login_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not g.user:
            flash("Please log in to continue.", "warning")
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapped

def admin_required(fn):
    @wraps(fn)
    @login_required
    def wrapped(*args, **kwargs):
        if g.user["role"] != "admin":
            abort(403)
        return fn(*args, **kwargs)
    return wrapped

@app.route("/")
def index():
    return redirect(url_for("dashboard") if g.user else url_for("login"))

@app.route("/register", methods=["GET", "POST"])
def register():
    if g.user:
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        referral = request.form.get("referral", "").strip().upper()
        if len(username) < 3 or len(username) > 30 or not username.replace("_", "").isalnum():
            flash("Username must be 3–30 characters (letters, numbers, underscores).", "danger")
            return render_template("register.html")
        if len(password) < 10:
            flash("Use a password with at least 10 characters.", "danger")
            return render_template("register.html")
        code = secrets.token_urlsafe(6).replace("-", "").replace("_", "")[:8].upper()
        with connect_db() as con:
            referred_by = None
            if referral:
                row = con.execute("SELECT id FROM users WHERE referral_code=?", (referral,)).fetchone()
                if not row:
                    flash("That referral code was not found. Leave it blank or check it.", "danger")
                    return render_template("register.html")
                referred_by = row["id"]
            try:
                cur = con.execute(
                    "INSERT INTO users(username,password_hash,referral_code,referred_by,created_at) VALUES(?,?,?,?,?)",
                    (username, generate_password_hash(password), code, referred_by, now())
                )
                uid = cur.lastrowid
                con.execute("INSERT INTO audit_log(actor_id,action,created_at) VALUES(?,?,?)",
                            (uid, "account_created", now()))
            except sqlite3.IntegrityError:
                flash("That username is already taken.", "danger")
                return render_template("register.html")
        session.clear()
        session["user_id"] = uid
        session.permanent = True
        return redirect(url_for("dashboard"))
    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if g.user:
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        with connect_db() as con:
            user = con.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
        if not user or not check_password_hash(user["password_hash"], password):
            flash("Incorrect username or password.", "danger")
            return render_template("login.html")
        session.clear()
        session["user_id"] = user["id"]
        session.permanent = True
        with connect_db() as con:
            con.execute("INSERT INTO audit_log(actor_id,action,created_at) VALUES(?,?,?)",
                        (user["id"], "login", now()))
        return redirect(url_for("dashboard"))
    return render_template("login.html")

@app.route("/logout", methods=["POST"])
@login_required
def logout():
    session.clear()
    flash("You are logged out.", "success")
    return redirect(url_for("login"))

@app.route("/dashboard")
@login_required
def dashboard():
    with connect_db() as con:
        team = con.execute("SELECT COUNT(*) AS n FROM users WHERE referred_by=?", (g.user["id"],)).fetchone()["n"]
        requests = con.execute("SELECT * FROM wallet_requests WHERE user_id=? ORDER BY id DESC LIMIT 5",
                               (g.user["id"],)).fetchall()
        all_requests = con.execute("SELECT COUNT(*) AS n FROM wallet_requests WHERE user_id=?",
                                   (g.user["id"],)).fetchone()["n"]
    return render_template("dashboard.html", team=team, requests=requests, all_requests=all_requests)

@app.route("/members")
@login_required
def members():
    with connect_db() as con:
        rows = con.execute("SELECT username,created_at FROM users WHERE referred_by=? ORDER BY id DESC",
                           (g.user["id"],)).fetchall()
    return render_template("members.html", members=rows)

@app.route("/wallet", methods=["GET", "POST"])
@login_required
def wallet():
    if request.method == "POST":
        kind = request.form.get("kind")
        raw = request.form.get("amount", "")
        try:
            amount = round(float(raw), 2)
        except (TypeError, ValueError):
            amount = 0
        if kind not in ("deposit_demo", "withdrawal_demo"):
            abort(400)
        if amount <= 0 or amount > 100000:
            flash("Enter a demo amount between 0.01 and 100000.", "danger")
            return redirect(url_for("wallet"))
        with connect_db() as con:
            con.execute("INSERT INTO wallet_requests(user_id,amount,request_type,status,created_at) VALUES(?,?,?,?,?)",
                        (g.user["id"], amount, kind, "pending", now()))
            con.execute("INSERT INTO audit_log(actor_id,action,created_at) VALUES(?,?,?)",
                        (g.user["id"], kind + "_created", now()))
        flash("Demo request saved as pending. No real money was moved.", "success")
        return redirect(url_for("wallet"))
    with connect_db() as con:
        rows = con.execute("SELECT * FROM wallet_requests WHERE user_id=? ORDER BY id DESC",
                           (g.user["id"],)).fetchall()
    return render_template("wallet.html", requests=rows)

@app.route("/admin")
@admin_required
def admin():
    with connect_db() as con:
        users = con.execute("SELECT id,username,role,referral_code,created_at FROM users ORDER BY id DESC LIMIT 100").fetchall()
        requests = con.execute("""SELECT w.*,u.username FROM wallet_requests w
                                  JOIN users u ON u.id=w.user_id ORDER BY w.id DESC LIMIT 100""").fetchall()
    return render_template("admin.html", users=users, requests=requests)

@app.route("/admin/request/<int:request_id>", methods=["POST"])
@admin_required
def update_request(request_id):
    status = request.form.get("status")
    if status not in ("approved_demo", "rejected"):
        abort(400)
    with connect_db() as con:
        con.execute("UPDATE wallet_requests SET status=? WHERE id=?", (status, request_id))
        con.execute("INSERT INTO audit_log(actor_id,action,created_at) VALUES(?,?,?)",
                    (g.user["id"], "wallet_request_" + status, now()))
    flash("Demo request updated. This does not transfer money.", "success")
    return redirect(url_for("admin"))

@app.errorhandler(403)
def forbidden(_):
    return render_template("error.html", code=403, message="You do not have permission to view this page."), 403

@app.errorhandler(404)
def not_found(_):
    return render_template("error.html", code=404, message="Page not found."), 404

@app.cli.command("create-admin")
@click.argument("username")
@click.password_option()
def create_admin(username, password):
    """Create an admin account: flask --app app create-admin YOUR_USERNAME"""
    init_db()
    with connect_db() as con:
        code = secrets.token_urlsafe(6).replace("-", "").replace("_", "")[:8].upper()
        try:
            con.execute("INSERT INTO users(username,password_hash,referral_code,role,created_at) VALUES(?,?,?,?,?)",
                        (username, generate_password_hash(password), code, "admin", now()))
        except sqlite3.IntegrityError:
            raise click.ClickException("Username already exists.")
    click.echo("Admin account created.")

if __name__ == "__main__":
    init_db()
    app.run(debug=os.environ.get("FLASK_DEBUG", "0") == "1")
