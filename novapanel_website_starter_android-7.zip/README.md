# NovaPanel — secure dashboard starter

Android-friendly Flask + SQLite starter inspired by a dark neon dashboard. Includes:
- Account registration and login with hashed passwords
- CSRF protection on forms
- Personal referral codes and referred-member list
- Demo wallet request ledger (pending/approved-demo/rejected)
- Admin request review and basic audit log
- Responsive layout for mobile screens

## Important boundaries
This is a working starter, not a production financial platform. The wallet is a **demo ledger only**: it does not hold, send, receive, or calculate real money. Do not show fake earnings or promise returns. Real payments, withdrawals, balances, identity checks, fraud controls, privacy terms, legal/compliance review, backups, monitoring and security testing must be designed and reviewed before any real financial use.

## Run locally
Requires Python 3.10+.

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Android/Termux or Linux: source .venv/bin/activate
pip install -r requirements.txt
flask --app app run
```
Open the local address printed by Flask in your browser. For local development only, HTTP is okay. Do not expose the development server directly to the public internet.

## Create an administrator
In a second terminal, with the virtual environment active:

```bash
flask --app app create-admin YOUR_ADMIN_USERNAME
```
The command prompts for the admin password. Do not share it. Normal users cannot assign themselves admin privileges.

## Before public deployment
1. Set a long random `SECRET_KEY` through the hosting provider's environment settings.
2. Set `COOKIE_SECURE=1` and use HTTPS.
3. Use a production WSGI server (for example Gunicorn) behind a properly configured HTTPS reverse proxy.
4. Keep dependencies updated; add rate limiting, account recovery, email verification, security monitoring, backups, and a privacy policy.
5. Review applicable laws and platform/provider rules before enabling any real payment feature.
6. Never collect users' banking passwords, OTPs, seed phrases, or crypto private keys.

## Current pages
- `/register`
- `/login`
- `/dashboard`
- `/members`
- `/wallet`
- `/admin` (admins only)

## Note
The app creates its SQLite database automatically on first request. For a larger deployment, move to managed PostgreSQL and a proper migration workflow.

## Optional cloud deployment outline (phone-friendly)
1. Upload these project files to a private GitHub repository (do not upload any database containing real user data).
2. Create a Python web service on a host that supports Flask/Gunicorn and connect the repository.
3. Set `SECRET_KEY` to a long random secret in the host's environment settings; enable HTTPS.
4. Note: the starter uses SQLite, which may not persist across some hosts' redeploys/restarts. For a durable public deployment, configure a managed PostgreSQL database and update the app's database layer before using it with real users.
5. Test registration, login, referral pages and admin access with dummy accounts only.
